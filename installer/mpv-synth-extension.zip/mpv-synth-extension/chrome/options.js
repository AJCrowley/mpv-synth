// ── Compatibility shim ──────────────────────────────────────────────────────
const api = (typeof browser !== 'undefined') ? browser : chrome;

// ── Default values ──────────────────────────────────────────────────────────
const DEFAULT_MPV    = 'C:\\Program Files\\mpv-synth';
const DEFAULT_CONFIG = 'C:\\Program Files\\mpv-synth\\portable_config';
const DEFAULT_CACHE  = 30;
const DEFAULT_RES    = '2160';

// ── Elements ────────────────────────────────────────────────────────────────
const mpvInput    = document.getElementById('mpvLocation');
const cfgInput    = document.getElementById('configLocation');
const browseMpv   = document.getElementById('browseMpv');
const browseCfg   = document.getElementById('browseConfig');
const saveBtn     = document.getElementById('saveBtn');
const statusEl    = document.getElementById('status');
const previewEl   = document.getElementById('preview');
const cacheSlider = document.getElementById('cacheSecs');
const cacheVal    = document.getElementById('cacheSecsVal');
const resLimit    = document.getElementById('resLimit');

// ── Helper: normalise to Windows backslashes ─────────────────────────────────
function toWinPath(p) { return p.replace(/\//g, '\\'); }

// ── Write defaults to storage on install ─────────────────────────────────────
api.runtime.onInstalled.addListener(() => {
  api.storage.sync.get(
    ['mpvLocation', 'configLocation', 'cacheSecs', 'resLimit'],
    (existing) => {
      const defaults = {};
      if (!existing.mpvLocation)  defaults.mpvLocation  = DEFAULT_MPV;
      if (!existing.configLocation) defaults.configLocation = DEFAULT_CONFIG;
      if (existing.cacheSecs === undefined) defaults.cacheSecs = DEFAULT_CACHE;
      if (!existing.resLimit)     defaults.resLimit     = DEFAULT_RES;
      if (Object.keys(defaults).length > 0) {
        api.storage.sync.set(defaults);
      }
    }
  );
});

// ── Load saved settings ─────────────────────────────────────────────────────
api.storage.sync.get(
  ['mpvLocation', 'configLocation', 'cacheSecs', 'resLimit'],
  (s) => {
    mpvInput.value = s.mpvLocation ? toWinPath(s.mpvLocation) : DEFAULT_MPV;
    cfgInput.value = s.configLocation ? toWinPath(s.configLocation) : DEFAULT_CONFIG;

    cacheSlider.value = s.cacheSecs !== undefined ? s.cacheSecs : DEFAULT_CACHE;
    cacheVal.textContent = cacheSlider.value + 's';

    resLimit.value = s.resLimit || DEFAULT_RES;

    updatePreview();
  }
);

// ── Slider live display ──────────────────────────────────────────────────────
cacheSlider.addEventListener('input', () => {
  cacheVal.textContent = cacheSlider.value + 's';
  updatePreview();
});

resLimit.addEventListener('change', updatePreview);

// ── Live preview ────────────────────────────────────────────────────────────
function updatePreview() {
  const mpv  = mpvInput.value.trim() || DEFAULT_MPV;
  const cfg  = cfgInput.value.trim() || DEFAULT_CONFIG;
  const secs = cacheSlider.value;
  const res  = resLimit.value;
  const url  = 'https://www.youtube.com/watch?v=example';

  let fmt = '';
  if (res !== 'best') {
    fmt = ` --ytdl-format=bestvideo[height<=?${res}][vcodec!=?vp9]+bestaudio/best`;
  }

  previewEl.innerHTML =
    `<span>${mpv}\\mpv</span> --config-dir="${cfg}"` +
    ` --cache=yes --cache-secs=${secs} --ytdl=yes${fmt}` +
    ` <span>${url}</span>`;
}

mpvInput.addEventListener('input', updatePreview);
cfgInput.addEventListener('input', updatePreview);

// ── Browse buttons ──────────────────────────────────────────────────────────
async function browseFolder(targetInput) {
  const btn = targetInput === mpvInput ? browseMpv : browseCfg;
  btn.disabled = true;
  btn.textContent = '⏳ …';

  try {
    const response = await new Promise((resolve, reject) => {
      api.runtime.sendMessage({ action: 'browse_folder' }, (r) => {
        if (api.runtime.lastError) reject(new Error(api.runtime.lastError.message));
        else resolve(r);
      });
    });

    if (response && response.folder) {
      targetInput.value = toWinPath(response.folder);
      updatePreview();
    } else if (response && response.error) {
      showStatus('Native host error: ' + response.error, 'err');
    }
  } catch (e) {
    showStatus('Could not contact native host. Is it installed? See README.', 'err');
  } finally {
    btn.disabled = false;
    btn.textContent = '📁 Browse';
  }
}

browseMpv.addEventListener('click', () => browseFolder(mpvInput));
browseCfg.addEventListener('click', () => browseFolder(cfgInput));

// ── Save ────────────────────────────────────────────────────────────────────
saveBtn.addEventListener('click', () => {
  const mpv  = mpvInput.value.trim() || DEFAULT_MPV;
  const cfg  = cfgInput.value.trim() || DEFAULT_CONFIG;
  const secs = parseInt(cacheSlider.value, 10);
  const res  = resLimit.value;

  if (!mpv || !cfg) {
    showStatus('Please fill in both path fields before saving.', 'err');
    return;
  }

  api.storage.sync.set(
    { mpvLocation: mpv, configLocation: cfg, cacheSecs: secs, resLimit: res },
    () => {
      showStatus('✓ Settings saved!', 'ok');
    }
  );
});

// ── Status helper ───────────────────────────────────────────────────────────
function showStatus(msg, type) {
  statusEl.textContent = msg;
  statusEl.className = type;
  clearTimeout(showStatus._t);
  if (type === 'ok') {
    showStatus._t = setTimeout(() => { statusEl.className = ''; }, 3000);
  }
}