// ── Native Messaging Host identifier (must match native/mpv_synth_host.json "name")
const NATIVE_HOST = 'com.mpvsynth.launcher';

// ── Compatibility shim: normalise browser vs chrome namespaces ──────────────
const api = (typeof browser !== 'undefined') ? browser : chrome;

// ── Default values ──────────────────────────────────────────────────────────
const DEFAULT_MPV    = 'C:\\Program Files\\mpv-synth';
const DEFAULT_CONFIG = 'C:\\Program Files\\mpv-synth\\portable_config';
const DEFAULT_CACHE  = 30;
const DEFAULT_RES    = '2160';

// ── Create context menu entries on install ──────────────────────────────────
api.runtime.onInstalled.addListener(() => {
  // Right-click on a link
  api.contextMenus.create({
    id: 'play-link-in-mpv-synth',
    title: 'Play link in mpv-synth',
    contexts: ['link']
  });
  // Right-click anywhere on a page that contains video
  api.contextMenus.create({
    id: 'play-page-in-mpv-synth',
    title: 'Play this page in mpv-synth',
    contexts: ['page', 'video']
  });
});

// ── Helper: send a one-shot message to the native host ─────────────────────
function sendNative(message) {
  return new Promise((resolve, reject) => {
    if (typeof browser !== 'undefined' && browser.runtime.sendNativeMessage) {
      browser.runtime.sendNativeMessage(NATIVE_HOST, message)
        .then(resolve)
        .catch(reject);
    } else {
      chrome.runtime.sendNativeMessage(NATIVE_HOST, message, (response) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve(response);
        }
      });
    }
  });
}

// ── Build the URL to play based on context ──────────────────────────────────
function getUrlFromInfo(info, tab) {
  if (info.menuItemId === 'play-link-in-mpv-synth') return info.linkUrl;
  return (tab && tab.url) || info.pageUrl;
}

// ── Context menu click handler ─────────────────────────────────────────────
api.contextMenus.onClicked.addListener((info, tab) => {
  const knownItems = ['play-link-in-mpv-synth', 'play-page-in-mpv-synth'];
  if (!knownItems.includes(info.menuItemId)) return;

  const url = getUrlFromInfo(info, tab);
  if (!url) return;

  api.storage.sync.get(
    ['mpvLocation', 'configLocation', 'cacheSecs', 'resLimit'],
    (settings) => {
      const mpvLocation    = settings.mpvLocation    || DEFAULT_MPV;
      const configLocation = settings.configLocation || DEFAULT_CONFIG;
      const cacheSecs      = settings.cacheSecs !== undefined ? settings.cacheSecs : DEFAULT_CACHE;
      const resLimit        = settings.resLimit       || DEFAULT_RES;

      sendNative({
        action:          'play',
        mpv_location:    mpvLocation,
        config_location: configLocation,
        cache_secs:      cacheSecs,
        res_limit:       resLimit,
        url:             url
      }).catch((err) => {
        console.error('[mpv-synth] Native messaging error:', err.message);
      });
    }
  );
});

// ── Toolbar icon click → open options ─────────────────────────────────────
if (api.action) {
  api.action.onClicked.addListener(() => api.runtime.openOptionsPage());
} else if (api.browserAction) {
  api.browserAction.onClicked.addListener(() => api.runtime.openOptionsPage());
}

// ── Message listener for options page (browse-folder requests) ─────────────
api.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.action === 'browse_folder') {
    sendNative({ action: 'browse_folder' })
      .then((response) => sendResponse({ folder: response.folder || '' }))
      .catch((err)  => sendResponse({ folder: '', error: err.message }));
    return true;
  }
});